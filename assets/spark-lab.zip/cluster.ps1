﻿# Bring the services up
function startServices {
  docker start nodemaster node2 node3
  sleep 3
  echo ">> Starting hdfs ..."
  docker exec -u hadoop -it nodemaster hadoop/sbin/start-dfs.sh
  sleep 3
  echo ">> Starting yarn ..."
  docker exec -u hadoop -d nodemaster hadoop/sbin/start-yarn.sh
  sleep 3
  echo ">> Starting Spark ..."
  docker exec -u hadoop -d nodemaster /home/hadoop/sparkcmd.sh start
  docker exec -u hadoop -d node2 /home/hadoop/sparkcmd.sh start
  docker exec -u hadoop -d node3 /home/hadoop/sparkcmd.sh start
  sleep 3
  docker exec -u hadoop -it nodemaster /home/hadoop/hadoop/bin/hadoop fs -mkdir -p .
  echo ">> Starting jupyter notebook server ..."
  $masterIp=(docker inspect -f "{{ .NetworkSettings.Networks.sparknet.IPAddress }}" nodemaster)
  docker exec -u hadoop -d nodemaster jupyter notebook --ip=$masterIp --port=8888 --notebook-dir='/opt/spark-apps' --NotebookApp.token='' --NotebookApp.password=''

  show_info
}

function show_info {
  $masterIp=(docker inspect -f "{{ .NetworkSettings.Networks.sparknet.IPAddress }}" nodemaster)
  $hadoop = $masterIp+":8088"
  $spark = $masterIp+":8080"
  $hdfs = $masterIp+":9870"
  $jupyter = $masterIp+":8888"
  echo "Hadoop info @ nodemaster: http://$hadoop/cluster"
  echo "Spark info @ nodemaster:  http://$spark/"
  echo "DFS Health @ nodemaster:  http://$hdfs/dfshealth.html"
  echo "Jupyter notebook:  http://$jupyter/?tree"
}

if ($args[0] -eq "start" ){
  startServices
  exit
}

if ($args[0] -eq "stop" ){
  docker exec -u hadoop -d nodemaster /home/hadoop/sparkcmd.sh stop
  docker exec -u hadoop -d node2 /home/hadoop/sparkcmd.sh stop
  docker exec -u hadoop -d node3 /home/hadoop/sparkcmd.sh stop
  docker stop nodemaster node2 node3
  exit
}

if ( $args[0] -eq "deploy" ){
  docker rm -f (docker ps -aq) # delete old containers
  docker network rm sparknet
  docker network create --driver bridge sparknet # create custom network
   
  # 3 nodes
  echo ">> Starting nodes master and worker nodes ..."
  docker run -d -p 4040:4040  -p 8088:8088  -p 8080:8080  -p 8888:8888  -p 9870:9870 -p 18080:18080 --network sparknet --name nodemaster -h nodemaster -v $PSScriptRoot/spark-apps:/opt/spark-apps -it hhmida/sparkbase
  docker run -dP --network sparknet --name node2 -it -h node2 -v $PSScriptRoot/spark-apps:/opt/spark-apps hhmida/sparkbase
  docker run -dP --network sparknet --name node3 -it -h node3 -v $PSScriptRoot/spark-apps:/opt/spark-apps hhmida/sparkbase

  # Format nodemaster
  echo ">> Formatting hdfs ..."
  docker exec -u hadoop -it nodemaster hadoop/bin/hdfs namenode -format
  startServices
  exit
}

if ($args[0] -eq "info"){
  show_info
  exit
}

echo "Usage: cluster.sh deploy|start|stop"
echo "                 deploy - create a new Docker network"
echo "                 start  - start the existing containers"
echo "                 stop   - stop the running containers" 
echo "                 info   - useful URLs" 
